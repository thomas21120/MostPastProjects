// Compiler Theory and Design Project 3
// Lindley, Thomas
// 29NOV2021
// This file contains function definitions for the evaluation functions

typedef char* CharPtr;
enum Operators {LESS, LESSE, EQUAL, NOTEQUAL, GREATER, GREATERE, ADD, SUBTRACT, DIVIDE, MULTIPLY};

double evaluateReduction(Operators operator_, double head, double tail);
double evaluateRelational(double left, Operators operator_, double right);
double evaluateArithmetic(double left, Operators operator_, double right);

