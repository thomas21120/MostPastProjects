// Compiler Theory and Design
// Lindley, Thomas
// 13Dec2021
// This file contains the bodies of the type checking functions

#include <string>
#include <vector>

using namespace std;

#include "types.h"
#include "listing.h"

void checkAssignment(Types lValue, Types rValue, string message)
{
	if ((lValue != MISMATCH && rValue != MISMATCH) && (lValue == INT_TYPE && rValue == REAL_TYPE)){
		appendError(GENERAL_SEMANTIC, "Illegal Narrowing " + message);
	}else if (lValue != MISMATCH && rValue != MISMATCH && lValue != rValue)
		appendError(GENERAL_SEMANTIC, "Type Mismatch on " + message);
}

Types checkIf(Types condition, Types ifThen, Types ifElse){
	if (condition == MISMATCH)
		return MISMATCH;
	if(condition != BOOL_TYPE){
		appendError(GENERAL_SEMANTIC, "If Expression Must Be Boolean");
		return MISMATCH;
	} 
	if(ifThen != ifElse){
		appendError(GENERAL_SEMANTIC, "If-Then Type Mismatch ");
		return MISMATCH;
	}
	return ifThen;
}

Types checkArithmetic(Types left, Types right)
{
	if (left == MISMATCH || right == MISMATCH)
		return MISMATCH;
	if (left == BOOL_TYPE || right == BOOL_TYPE)
	{
		appendError(GENERAL_SEMANTIC, "Numeric Type Required");
		return MISMATCH;
	}
	if(left == REAL_TYPE || right == REAL_TYPE){
		return REAL_TYPE;
	}
	return INT_TYPE;
}

Types checkRem(Types left, Types right)
{
	if (left == MISMATCH || right == MISMATCH)
		return MISMATCH;
	if (left == BOOL_TYPE || right == BOOL_TYPE)
	{
		appendError(GENERAL_SEMANTIC, "Remainder Operator Requires Integer Operands");
		return MISMATCH;
	}
	if(left == REAL_TYPE || right == REAL_TYPE){
		appendError(GENERAL_SEMANTIC, "Remainder Operator Requires Integer Operands");
		return MISMATCH;
	}
	return INT_TYPE;
}


Types checkLogical(Types left, Types right)
{
	if (left == MISMATCH || right == MISMATCH)
		return MISMATCH;
	if (left != BOOL_TYPE || right != BOOL_TYPE)
	{
		appendError(GENERAL_SEMANTIC, "Boolean Type Required");
		return MISMATCH;
	}	
		return BOOL_TYPE;
	return MISMATCH;
}

Types checkRelational(Types left, Types right)
{
	if (checkArithmetic(left, right) == MISMATCH)
		return MISMATCH;
	return BOOL_TYPE;
}
